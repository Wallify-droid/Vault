# AppVault (Notes disguise)

A fully functional notes app (Kotlin + Jetpack Compose + Room) that doubles as a hidden-apps
gateway. It behaves exactly like a normal notes app. Typing your secret phrase into any note's
body and tapping Save does **not** save that note — instead it opens a hidden screen listing
apps you've chosen to keep out of your everyday app drawer.

## How it works

- **Notes**: standard CRUD notes list (`ui/notes`), stored locally in Room (`data/`).
- **Secret phrase**: set once on first launch (`ui/home/SetupScreen.kt`), stored encrypted via
  `androidx.security` `EncryptedSharedPreferences` (`util/SecretVault.kt`) — never stored in plain text,
  never hardcoded.
- **Trigger point**: checked only in `NoteEditScreen.kt`, only when you tap the Save (check) icon.
  If the note body matches your phrase exactly, nothing is saved and you're routed to `HiddenScreen`.
- **Hidden apps**: `HiddenScreen.kt` lists apps you've hidden and lets you launch them via
  `Intent` (`util/InstalledAppsProvider.kt`). Hidden state lives in Room (`HiddenApp` table) —
  no root, no device-owner, no system permission beyond the `<queries>` block needed to see
  other installed apps.
- **Optional launcher role**: the manifest declares `MainActivity` with the `HOME` category, so
  users can set this app as their default Home screen if they want hidden apps to also disappear
  from the home screen itself (Android Settings > Apps > Default apps > Home app).

## Opening the project

1. Install **Android Studio** (Koala/2024.1 or newer).
2. `File > Open` and select this `AppVault` folder.
3. Let Android Studio generate the Gradle wrapper on first sync (or run
   `gradle wrapper --gradle-version 8.7` from a terminal with Gradle installed if you want to
   build from the CLI instead of Studio).
4. Run on a device/emulator with **API 26+**.

## First run

1. App opens to the Setup screen — pick your secret phrase.
2. You land on the Notes list. Use it like any notes app.
3. To hide an app: open any note, type your secret phrase as the entire note body, tap Save (✓).
   You land on **Hidden apps** → **Hide more** → pick apps.
4. To reach the hidden screen again later: same trick — new note, type the phrase, tap Save.

## Notes on Play Store policy

Apps like this are allowed on Google Play as "app hider" / vault utilities as long as they don't
misrepresent themselves or use restricted permissions. This build uses no restricted permissions —
just the `<queries>` block for seeing installed apps, which is standard for launcher-style apps.
