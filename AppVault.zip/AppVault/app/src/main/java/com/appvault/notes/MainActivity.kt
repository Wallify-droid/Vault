package com.appvault.notes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.appvault.notes.ui.Routes
import com.appvault.notes.ui.hidden.HiddenScreen
import com.appvault.notes.ui.home.SetupScreen
import com.appvault.notes.ui.notes.NoteEditScreen
import com.appvault.notes.ui.notes.NotesListScreen
import com.appvault.notes.ui.theme.AppVaultTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppVaultTheme {
                val navController = rememberNavController()
                val startDestination = if (viewModel.secretVault.hasSecretSet()) Routes.HOME else Routes.SETUP

                NavHost(navController = navController, startDestination = startDestination) {

                    composable(Routes.SETUP) {
                        SetupScreen(viewModel = viewModel) {
                            navController.navigate(Routes.HOME) {
                                popUpTo(Routes.SETUP) { inclusive = true }
                            }
                        }
                    }

                    composable(Routes.HOME) {
                        NotesListScreen(
                            viewModel = viewModel,
                            onOpenNote = { id -> navController.navigate(Routes.noteEdit(id)) }
                        )
                    }

                    composable(
                        route = Routes.NOTE_EDIT,
                        arguments = listOf(navArgument("noteId") { type = NavType.LongType })
                    ) { backStackEntry ->
                        val noteId = backStackEntry.arguments?.getLong("noteId") ?: 0L
                        NoteEditScreen(
                            viewModel = viewModel,
                            noteId = noteId,
                            onBack = { navController.popBackStack() },
                            onSecretUnlocked = {
                                navController.navigate(Routes.HIDDEN) {
                                    // Don't leave the "unlocking" note edit screen on the back stack
                                    popUpTo(Routes.HOME)
                                }
                            }
                        )
                    }

                    composable(Routes.HIDDEN) {
                        HiddenScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack(Routes.HOME, inclusive = false) }
                        )
                    }
                }
            }
        }
    }
}
