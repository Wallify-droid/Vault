package com.appvault.notes

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.appvault.notes.data.AppDatabase
import com.appvault.notes.data.HiddenApp
import com.appvault.notes.data.Note
import com.appvault.notes.util.AppInfo
import com.appvault.notes.util.InstalledAppsProvider
import com.appvault.notes.util.SecretVault
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val noteDao = db.noteDao()
    private val hiddenAppDao = db.hiddenAppDao()
    val secretVault = SecretVault(application)

    val notes: StateFlow<List<Note>> = noteDao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val hiddenPackageNames: StateFlow<Set<String>> = hiddenAppDao.getAll()
        .map { list -> list.map { it.packageName }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())

    /** Apps shown in the normal (visible) drawer -- hidden ones filtered out. */
    val visibleApps: StateFlow<List<AppInfo>> = combine(_allApps, hiddenPackageNames) { all, hidden ->
        all.filter { it.packageName !in hidden }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Apps the user has chosen to hide -- only reachable via the secret screen. */
    val hiddenApps: StateFlow<List<AppInfo>> = combine(_allApps, hiddenPackageNames) { all, hidden ->
        all.filter { it.packageName in hidden }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun refreshInstalledApps() {
        _allApps.value = InstalledAppsProvider.getLaunchableApps(getApplication())
    }

    fun launchApp(packageName: String) {
        InstalledAppsProvider.launchApp(getApplication(), packageName)
    }

    fun hideApp(packageName: String) = viewModelScope.launch {
        hiddenAppDao.hide(HiddenApp(packageName))
    }

    fun unhideApp(packageName: String) = viewModelScope.launch {
        hiddenAppDao.unhide(packageName)
    }

    fun saveNote(id: Long, title: String, body: String, onSaved: () -> Unit) = viewModelScope.launch {
        if (id == 0L) {
            noteDao.insert(Note(title = title, body = body))
        } else {
            noteDao.update(Note(id = id, title = title, body = body))
        }
        onSaved()
    }

    fun deleteNote(note: Note) = viewModelScope.launch {
        noteDao.delete(note)
    }

    suspend fun getNote(id: Long): Note? = noteDao.getById(id)
}
