package com.appvault.notes.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HiddenAppDao {
    @Query("SELECT * FROM hidden_apps")
    fun getAll(): Flow<List<HiddenApp>>

    @Query("SELECT packageName FROM hidden_apps")
    suspend fun getAllPackageNamesOnce(): List<String>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun hide(app: HiddenApp)

    @Query("DELETE FROM hidden_apps WHERE packageName = :packageName")
    suspend fun unhide(packageName: String)
}
