package com.appvault.notes.ui

object Routes {
    const val SETUP = "setup"
    const val HOME = "home"
    const val NOTE_EDIT = "note_edit/{noteId}"
    const val HIDDEN = "hidden"

    fun noteEdit(noteId: Long) = "note_edit/$noteId"
}
