package com.appvault.notes.ui.hidden

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawable.toBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.appvault.notes.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HiddenScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val hiddenApps by viewModel.hiddenApps.collectAsState()
    val visibleApps by viewModel.visibleApps.collectAsState()
    var showPicker by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.refreshInstalledApps() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hidden apps") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { showPicker = true }) { Text("Hide more") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            if (hiddenApps.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nothing hidden yet. Tap \"Hide more\" to pick apps.")
                }
            } else {
                LazyColumn {
                    items(hiddenApps, key = { it.packageName }) { app ->
                        ListItem(
                            headlineContent = { Text(app.label) },
                            leadingContent = {
                                Image(
                                    bitmap = app.icon.toBitmap().asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp)
                                )
                            },
                            trailingContent = {
                                TextButton(onClick = { viewModel.unhideApp(app.packageName) }) {
                                    Text("Unhide")
                                }
                            },
                            modifier = Modifier.clickable {
                                viewModel.launchApp(app.packageName)
                            }
                        )
                        Divider()
                    }
                }
            }
        }
    }

    if (showPicker) {
        AppPickerDialog(
            apps = visibleApps,
            onDismiss = { showPicker = false },
            onPick = { pkg ->
                viewModel.hideApp(pkg)
            }
        )
    }
}

@Composable
private fun AppPickerDialog(
    apps: List<com.appvault.notes.util.AppInfo>,
    onDismiss: () -> Unit,
    onPick: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose an app to hide") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                items(apps, key = { it.packageName }) { app ->
                    ListItem(
                        headlineContent = { Text(app.label) },
                        leadingContent = {
                            Image(
                                bitmap = app.icon.toBitmap().asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.size(32.dp)
                            )
                        },
                        modifier = Modifier.clickable {
                            onPick(app.packageName)
                            onDismiss()
                        }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
