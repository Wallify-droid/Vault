package com.appvault.notes.util

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the user's secret unlock phrase encrypted at rest.
 * The phrase is never hardcoded — the user sets it during first-run setup.
 */
class SecretVault(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secret_vault_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun hasSecretSet(): Boolean = prefs.contains(KEY_SECRET)

    fun setSecret(code: String) {
        prefs.edit().putString(KEY_SECRET, code).apply()
    }

    fun matches(input: String): Boolean {
        val stored = prefs.getString(KEY_SECRET, null) ?: return false
        // Trim so trailing spaces/newlines from a note field don't break the match
        return stored == input.trim()
    }

    companion object {
        private const val KEY_SECRET = "secret_code"
    }
}
